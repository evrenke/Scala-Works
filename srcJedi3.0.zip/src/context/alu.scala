package context

import value._
import expression._
import scala.annotation.tailrec


//An arithmetic and logic unit that works with arguments of Value
//It has 9 operations, and each one has its own set of argument requirements
object alu {

  def execute(opcode: Identifier, args: List[Value]): Value = opcode.name match {
    case "add" => add(args) // n-ary
    case "mul" => mul(args) // n-ary
    case "sub" => sub(args) // n-ary
    case "div" => div(args) // n-ary
    case "less" => less(args) // binary
    case "equals" => same(args) // binary
    case "more" => more(args) // binary
    case "unequals" => unequals(args) // binary
    case "not" => not(args) // unary
    // variables
    case "dereference" => dereference(args)
    case "var" => makeVar(args)
    // primitive I/O ops:
    case "write" => write(args)
    // case "prompt" => prompt(args)
    // case "read" => read(args)
    // store ops
    /*
    case "store" => store(args)
    case "put" => put(args)
    case "rem" => rem(args)
    case "contains" => contains(args)
    case "map" => map(args)
    case "filter" => filter(args)
    case "get" => get(args)
    case "addLast" => addLast(args)
    case "size" => size(args)
    */
    case "nil" => getEmpty(args)
    case "cons" => pairCons(args)
    case "car" => pairCar(args)
    case "cdr" => pairCdr(args)
    case "list" => pairList(args)
    case _ => throw new UndefinedException(opcode)
  }

  private def add(args: List[Value]): Value = {

    @tailrec
    def helper(result: Addable, unseen: List[Value]): Addable =
      if (unseen == Nil) result
      else helper(result + unseen.head, unseen.tail)

    if (args.size < 2) throw new TypeException("2 or more inputs required by +")
    args.head match {
      case n: Addable => helper(args.head.asInstanceOf[Addable], args.tail)
      case _ => throw new TypeException("Inputs to + must be addable")
    }
  }

  private def mul(args: List[Value]): Value = {

    @tailrec
    def helper(result: Numeric, unseen: List[Value]): Numeric =
      if (unseen == Nil) result
      else helper(result * unseen.head, unseen.tail)

    if (args.size < 2) throw new TypeException("2 or more inputs required by *")
    args.head match {
      case n: Numeric => helper(args.head.asInstanceOf[Numeric], args.tail)
      case _ => throw new TypeException("Inputs to * must be numeric")
    }
  }

  private def sub(args: List[Value]): Value = {

    @tailrec
    def helper(result: Numeric, unseen: List[Value]): Numeric =
      if (unseen == Nil) result
      else helper(result - unseen.head, unseen.tail)

    if (args.size < 2) throw new TypeException("2 or more inputs required by -")
    args.head match {
      case n: Numeric => helper(args.head.asInstanceOf[Numeric], args.tail)
      case _ => throw new TypeException("Inputs to - must be numeric")
    }
  }

  private def div(args: List[Value]): Value = {

    @tailrec
    def helper(result: Numeric, unseen: List[Value]): Numeric =
      if (unseen == Nil) result
      else helper(result / unseen.head, unseen.tail)

    if (args.size < 2) throw new TypeException("2 or more inputs required by /")
    args.head match {
      case n: Numeric => helper(args.head.asInstanceOf[Numeric], args.tail)
      case _ => throw new TypeException("Inputs to / must be numeric")
    }
  }

  private def less(args: List[Value]): Value = {
    if (args.size != 2) throw new TypeException("2 inputs required by <")
    if (!args.head.isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to < must be orderable")
    Boole(args.head.asInstanceOf[Ordered[Value]] < args(1))
  }

  private def same(args: List[Value]): Value = {
    if (args.size != 2) throw new TypeException("2 inputs required by <")
    //if (!args.head.isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to < must be orderable")
    Boole(args.head == args(1))
  }

  private def more(args: List[Value]): Value = {
    if (args.size != 2) throw new TypeException("2 inputs required by >")
    if (!args.head.isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to > must be orderable")
    Boole(args.head.asInstanceOf[Ordered[Value]] > args(1))
  }

  private def unequals(args: List[Value]): Value = {
    if (args.size != 2) throw new TypeException("2 inputs required by !=")
    //if (!args.head.isInstanceOf[Ordered[Value]]) throw new TypeException("Inputs to != must be orderable")
    Boole(args.head != args(1))
  }

  private def not(args: List[Value]): Value = {
    if (args.size != 1) throw new TypeException("1 input required by !")
    if (!args.head.isInstanceOf[Boole]) throw new TypeException("Inputs to ! must be boolean")
    !args.head.asInstanceOf[Boole]
  }

  private def write(args: List[Value]): Value = {
    if(args.size != 1)
      throw new TypeException("1 input required by write")
    println(args.head)
    Notification.DONE
  }

  private def getEmpty(args: List[Value]) : Value = {
    empty
  }

  private def pairCons(args: List[Value]) : Value = {
    if (args.size != 2) throw new TypeException("2 inputs required by cons")
    Pair(args.head, args(1))
  }

  private def pairCar(args: List[Value]) : Value = {
    if(args.size != 1) {
      throw new TypeException("1 input required by car")

    }
    args.head.asInstanceOf[Pair].first
  }

  private def pairCdr(args: List[Value]) : Value = {
    if(args.size != 1)
      throw new TypeException("1 input required by cds")
    args.head.asInstanceOf[Pair].second
  }

  private def pairList(args: List[Value]) : Value = {
    if(args.size < 1)
      getEmpty(args)
    if (args.size == 1)
      Pair(args.head, getEmpty(args))
    else {
      Pair(args.head, pairList(args.drop(1)))
    }
  }

  private def dereference(args: List[Value]) : Value = {
    if(args.size != 1)
      throw new TypeException("Only 1 input required by dereference")
    if(!args.head.isInstanceOf[Variable]) {
      throw new TypeException("Inputs to dereference must be a variable")
    }
    args.head.asInstanceOf[Variable].content
  }

  private def makeVar(args: List[Value]) : Value = {
    if(args.size != 1)
      throw new TypeException("Only 1 input required by var")
    Variable(args.head)
  }
}

