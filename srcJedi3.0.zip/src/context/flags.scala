package context

object flags {
  val BY_REF = 0
  val BY_NAME = 1
  var paramPassing: Int = BY_REF
}