package expression
import context.{Environment, alu}
import value.{Boole, Value}

//Represents the disjunction of two Boole expressions together
case class Disjunction(expressions : List[Expression]) extends SpecialForm {
  override def execute(env: Environment): Value = if(expressions.length == 1) expressions.head.execute(env).asInstanceOf[Boole]
  else { // no need to calculate beyond head if head is true
    val headVal = expressions.head.execute(env).asInstanceOf[Boole]
    if(!headVal.value)
      Disjunction(expressions.drop(1)).execute(env)
    else headVal
  }
}
