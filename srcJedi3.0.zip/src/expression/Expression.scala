package expression
import context.Environment
import value.Value

//An expression is anything that has a value when it is executed within an environment
trait Expression {
  def execute(env : Environment) : Value
}
