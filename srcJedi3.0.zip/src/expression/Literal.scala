package expression
import context.Environment
import value.Value

//A trait that means that an object with trait has to always return itself when executed
//A literal object's value on execution it always itself
trait Literal extends Expression with Value with Equals {
  override final def execute(env: Environment): Value = this
}
