package expression

//A trait that states that the given expressions have special executable forms that calculate their values
trait SpecialForm extends Expression {

}
