package expression
import context.Environment
import value.{Closure, Value, Thunk}
import context.alu
import context.flags

// Represents a function call with the functions identifier in the alu, and the list of arguments
case class FunCall(val operation: Identifier,val operands: List[Expression]) extends Expression
{
  override def execute(env: Environment): Value = {
    if(env.contains(operation))
    {
      var args: List[Value] = Nil
        if (flags.paramPassing == flags.BY_NAME) {
          args = operands.map(MakeThunk(_).execute(env))
        } else { // BY_REF
          args = operands.map(_.execute(env))
        }
      env(operation).asInstanceOf[Closure].apply(args)
    }
    else {
      val values = operands.map(_.execute(env))
      alu.execute(operation, values)
    }
  }
}