package expression
import context.Environment
import value.{Notification, Value}

//Represents the declaration of an identifier to an expression in an environment
case class Declaration(name: Identifier, expression: Expression) extends SpecialForm {

  override def execute(env: Environment): Value =
    {
      if(env.put(name, expression.execute(env)).isInstanceOf[Option[Value]])
        Notification.OK
      else Notification.UNSPECIFIED
    }
}
