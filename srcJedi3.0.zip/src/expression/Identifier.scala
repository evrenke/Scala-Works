package expression
import context.Environment
import context.UndefinedException
import value.Value
import value.Thunk

//An Identifier is used to get a value from the environment
//It is paired in the environment to a value, and executing it returns that value
//It there is no pairing, then it is undefined, and throws an UndefinedException
case class Identifier(name: String) extends Expression {
  override def toString: String = name
  override def execute(env: Environment): Value = {
    val result = env(this)
    result match {
      case thunk: Thunk =>
        thunk.apply(Nil)
      case _ => result
    }
  }
}