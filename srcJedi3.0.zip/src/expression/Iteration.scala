package expression
import context.Environment
import value.{Boole, Notification, Value}

case class Iteration(condition: Expression, body : Expression) extends Expression {
  override def execute(env: Environment): Value = {
    while(condition.execute(env).asInstanceOf[Boole].value) {
      body.execute(env)
    }
    Notification.DONE
  }
}


