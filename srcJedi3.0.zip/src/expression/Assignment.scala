package expression
import context.{Environment, TypeException}
import value.{Notification, Value, Variable}

case class Assignment(vlb: Identifier, update: Expression) extends SpecialForm {
  override def execute(env: Environment): Value =
    if(!env(vlb).isInstanceOf[Variable]) { throw new TypeException("Must be of type Variable!")}
    else {
      env(vlb).asInstanceOf[Variable].content = update.execute(env)
      Notification.DONE
    }
}
