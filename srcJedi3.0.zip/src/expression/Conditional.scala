package expression
import context.Environment
import value.{Boole, Notification, Value}


//Represents a conditional statement, with given expressions for the condition, the result, and the alternative result if assigned
case class Conditional(condition : Expression, consequent : Expression, alternative: Expression = null) extends Expression {
  override def execute(env: Environment): Value = if(condition.execute(env).asInstanceOf[Boole].value) consequent.execute(env)
  else if (alternative != null) alternative.execute(env)
  else Notification.UNSPECIFIED
}
