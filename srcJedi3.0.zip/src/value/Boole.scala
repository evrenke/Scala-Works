package value
import context.TypeException
import expression.Literal

//Jedi representation of boolean true false values
//Implements boolean operations like and, or, not
//It also comes with default definitions TRUE and FALSE
case class Boole(value: Boolean) extends Literal {
  override def canEqual(that: Any): Boolean = that.isInstanceOf[Boole]

  override def equals(that: scala.Any): Boolean = that match {
    case that: Boole =>
      this.value == that.value
    case _ => false
  }
  override def toString: String = this.value.toString

  override def hashCode(): Int = value.hashCode()

  def &&(other : Value): Boole = other match {
    case x: Boole => Boole(value && x.value)
    case _ => throw new TypeException("Boole operand required")
  }

  def ||(other : Value): Boole = other match {
    case x: Boole => Boole(value || x.value)
    case _ => throw new TypeException("Boole operand required")
  }

  def unary_!(): Boole = Boole(!value)
}

object Boole {
  def TRUE: Boole = Boole(true)

  def FALSE: Boole = Boole(false)
}
