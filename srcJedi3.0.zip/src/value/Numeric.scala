package value

// a trait for numbers, that defines multiplication, subtraction, division, and negation for
trait Numeric extends Addable{
  def *(other: Value) : Numeric
  def -(other: Value) : Numeric
  def /(other: Value) : Numeric
  def unary_-() : Numeric
}
