package value

import context.Environment
import expression.{Expression, Identifier}

class Closure(val parameters: List[Identifier],val  body: Expression,val  defEnv: Environment) extends Value {
  def apply(args: List[Value]) : Value = {
    val tempEnv = new Environment(defEnv)
    tempEnv.bulkPut(parameters, args)
    body.execute(tempEnv)
  }
}
