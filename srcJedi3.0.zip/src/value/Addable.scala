package value
import expression.Literal

//A trait that means that two objects of an Addable class can be combined together
//Declares undefined + function for classes to implement
trait Addable extends Literal {
  def +(other: Value) : Addable
}
