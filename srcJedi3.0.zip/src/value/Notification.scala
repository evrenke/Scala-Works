package value

//A notification value that holds a String message for the system's internal changes
class Notification(val msg: String) extends Value {
  override def toString: String = msg
}

object Notification{
  def apply(s: String) = new Notification(s)
  val OK: Notification = Notification("OK")
  val DONE: Notification = Notification("DONE")
  val UNSPECIFIED: Notification = Notification("UNSPECIFIED")
}

