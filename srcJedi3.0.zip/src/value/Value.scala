package value

//a trait that signifies that the class represents some value
trait Value {

}
