package value

import context.Environment
import expression.{Expression, Identifier}

class Thunk(override val body: Expression, override val defEnv: Environment) extends Closure(Nil, body, defEnv){
  var cache: Value = null
  override def apply(args: List[Value]): Value = {
    if(cache == null)
      cache = super.apply(Nil)
    cache
  }
}
