package value

object empty extends Value{
  override def toString: String = "Nil"
}
