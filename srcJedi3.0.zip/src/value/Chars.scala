package value

import context.TypeException

//Jedi representation of String values
//It is an Addable and Ordered, allowing Chars to be concatenated and compared
case class Chars( str: String ) extends Addable with Ordered[Value] {
  def size: Exact = Exact(str.length)
  def subChars(from: Exact, to : Exact ): Chars =
    Chars(str.substring(from.value, to.value))

  override def +(other: Value): Addable = other match {
    case x: Chars => Chars(str + x.str)
    case x: Exact => Chars(str + x.toString())
    case x: Inexact => Chars(str + x.toString())
    case x: Boole => Chars(str + x.toString())
    case _ => throw new TypeException("String operand required")
  }

  override def compare(that: Value): Int = that match {
    case x: Chars => str.compare(x.str)
    case _ => throw new TypeException("Arguments must be comparable")
  }

  //override def canEqual(that: Any): Boolean = that.isInstanceOf[Chars]

  override def equals(that: scala.Any): Boolean = that match {
    case that: Chars =>
      this.str == that.str
    case _ => false
  }

  override def toString: String = str

  override def hashCode(): Int = str.hashCode()
}
